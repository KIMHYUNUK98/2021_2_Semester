import java.util.Iterator;
import java.util.LinkedList;

public class LinkedQueue<String> {

	LinkedList<String> link = new LinkedList<String>();
	private String front;
	private int count;
	
	public void setCount() {
		this.count = link.size();
	}
	
	public int getCount() {
		return count;
	}
	
	public void setFront() {
		this.front = link.getFirst();
	}
	
	public String getFront() {
		return front;
	}
	
	public void addtoQueue(String string) {
		// TODO Auto-generated method stub
		link.add(string);
	}

	public void showQueue() {
		// TODO Auto-generated method stub
		Iterator<String> iterator = link.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
	
	public String removeFromQueue() {
		if(isEmpty())
			this.front = null;
		else 
			this.front = link.getFirst();
		
		System.out.println("Removed the front item from the queue " + getFront());
		
		if(isEmpty())
			return null;
		else 
			return link.removeFirst();		
	}
	
	public boolean isEmpty() {
		if(link.isEmpty())
			return true;
		else 
			return false;
	}

	public int length() {
		// TODO Auto-generated method stub
		return link.size();
	}

}
