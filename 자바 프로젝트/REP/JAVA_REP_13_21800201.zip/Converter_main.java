import javax.swing.*;
import java.awt.*;

public class Converter_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Converter window = new Converter();
		window.setVisible(true);
	}

}
