import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Converter extends JFrame implements ActionListener {
	
	public static int WIDTH = 600;
	public static int HEIGHT = 300;

	JPanel buttonpanel = new JPanel(new GridLayout(3,1));
	JPanel buttonpanel1 = new JPanel(new BorderLayout());
	JPanel buttonpanel2 = new JPanel(new BorderLayout());
	JPanel buttonpanel3 = new JPanel(new BorderLayout());
	
	JPanel panel2 = new JPanel(new GridLayout(3,1));
	JPanel areapanel1 = new JPanel(new BorderLayout());
	JPanel areapanel2 = new JPanel(new BorderLayout());
	
	JTextField theText = new JTextField(20);
	JLabel area1 = new JLabel();
	JLabel area2 = new JLabel();
	
	JButton toBinary = new JButton("Convert to binary");
	JButton toOctal = new JButton("Convert to octal");
	JButton clear = new JButton("Clear");
	
	public Converter() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		setSize(WIDTH, HEIGHT);
		setTitle("Binary/Octal convertor");
		
		// TextField �߰�
		panel2.add(theText, BorderLayout.WEST);
		areapanel1.add(area1, BorderLayout.SOUTH);
		panel2.add(areapanel1);
		areapanel2.add(area2, BorderLayout.SOUTH);
		panel2.add(areapanel2);
		
		
		buttonpanel1.add(toBinary, BorderLayout.NORTH);
		buttonpanel.add(buttonpanel1);
		toBinary.addActionListener(this);
		buttonpanel2.add(toOctal, BorderLayout.NORTH);
		buttonpanel.add(buttonpanel2);
		toOctal.addActionListener(this);
		buttonpanel3.add(clear, BorderLayout.NORTH);
		buttonpanel.add(buttonpanel3);
		clear.addActionListener(this);

		
		contentPane.add(buttonpanel, BorderLayout.EAST);
		contentPane.add(panel2, BorderLayout.CENTER);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String actionCommand = e.getActionCommand();
		String new_arr="";
		int error = 0;
	
		
		if(actionCommand.equals("Convert to octal")) {		
			
			String arr = theText.getText().replaceAll(" ", "");
			
			// 0�� 1�� �ƴϸ� ���� ī��Ʈ ���ֱ�
			for(int i = 0 ; i < arr.length(); i++) {
				if(arr.charAt(i) != '0' && arr.charAt(i) != '1') {
					error++;
				}
			} 
			
			// error�� 1�� �̻� �߻����ٸ� ���� ���� ��� �ƴϸ� ���� ���� ���
			if(error > 0) area2.setText("Sorry, can not convert that.");
			else area2.setText("Value converted to octal.");
			
			// 3�� ������ �������� ������ �տ� 0 �߰�
			if(arr.length() % 3 != 0) {
				
				// 3���� ���� �������� ���� ���ڿ� �տ� ���� 0�� ������ �޶�����
				if(arr.length() % 3 == 1) {
					new_arr = "00" + arr;
				} else if(arr.length() % 3 == 2) {
					new_arr = "0" + arr;
				}
			// 3�� ������ ������ ���ٸ� new_arr�� ���ڿ��� �״�� �߰��Ѵ�.
			} else {
				new_arr = arr;
			}
			
			// ������ ��ȯ
			for(int i = 0 ; i < new_arr.length() ; i = i + 3) {
				if(new_arr.substring(i,i+3).equals("000")) {
					area1.setText(area1.getText() + "0");
				} else if(new_arr.substring(i,i+3).equals("001")) {
					area1.setText(area1.getText() + "1");
				} else if(new_arr.substring(i,i+3).equals("010")) {
					area1.setText(area1.getText() + "2");
				} else if(new_arr.substring(i,i+3).equals("011")) {
					area1.setText(area1.getText() + "3");
				} else if(new_arr.substring(i,i+3).equals("100")) {
					area1.setText(area1.getText() + "4");
				} else if(new_arr.substring(i,i+3).equals("101")) {
					area1.setText(area1.getText() + "5");
				} else if(new_arr.substring(i,i+3).equals("110")) {
					area1.setText(area1.getText() + "6");
				} else if(new_arr.substring(i,i+3).equals("111")) {
					area1.setText(area1.getText() + "7");
				}
			}
			
		} else if(actionCommand.equals("Convert to binary")) {
			
			String arr = theText.getText().replaceAll(" ", "");
			
			// 0�� 1�� �ƴϸ� ���� ī��Ʈ ���ֱ�
			for(int i = 0 ; i < arr.length(); i++) {
				if(arr.charAt(i) < '0' || arr.charAt(i) > '9') {
					error++;
				}
			} 
			
			// error�� 1�� �̻� �߻����ٸ� ���� ���� ��� �ƴϸ� ���� ���� ���
			if(error > 0) area2.setText("Sorry, can not convert that.");
			else area2.setText("Value converted to binary.");
			
			for(int i = 0 ; i < arr.length(); i++) {
				if(arr.charAt(i) == '0') {
					area1.setText(area1.getText() + "000");
				} else if(arr.charAt(i) == '1') {
					area1.setText(area1.getText() + "001");
				} else if(arr.charAt(i) == '2') {
					area1.setText(area1.getText() + "010");
				} else if(arr.charAt(i) == '3') {
					area1.setText(area1.getText() + "011");
				} else if(arr.charAt(i) == '4') {
					area1.setText(area1.getText() + "100");
				} else if(arr.charAt(i) == '5') {
					area1.setText(area1.getText() + "101");
				} else if(arr.charAt(i) == '6') {
					area1.setText(area1.getText() + "110");
				} else if(arr.charAt(i) == '7') {
					area1.setText(area1.getText() + "111");
				} 
			}
		} else if(actionCommand.equals("Clear")) {
			area1.setText("");
			area2.setText("");
			theText.setText("");
		}
	}
}
