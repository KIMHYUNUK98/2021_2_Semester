import java.util.*;

public class RecurPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		while(true) {
			System.out.println("Enter a string");
			String arr = s.nextLine();
			String palin = forPalindrome(arr);
			if(isPalindrome(palin)) {
				System.out.println("The sentence is a palindrome");
			} else {
				System.out.println("It is NOT a palindrome");
			}
			
			System.out.println("Enter another sentence?(y/n)");
			String ret = s.next();
			s.nextLine();
			if(ret.equals("n")) break;
			else {
				continue;
			}
		}
	}

	private static String forPalindrome(String arr) {
		// TODO Auto-generated method stub
		String arr1 = arr.replace(" ", "");
		String arr2 = arr1.replaceAll("\\p{Punct}", "");
		String arr3 = arr2.toLowerCase();
		return arr3;
	}

	private static boolean isPalindrome(String arr) {
		// TODO Auto-generated method stub
		if(arr.length() == 0 || arr.length() == 1)
			return true;
		if(arr.charAt(0) == arr.charAt(arr.length() -1))
			return isPalindrome(arr.substring(1, arr.length()-1));
		return false;
	}

}
