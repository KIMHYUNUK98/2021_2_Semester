
public class CH06_Time {
	
	private int time;
	private int hours;
	private int minutes;
	
	public CH06_Time() {
		time = 0;
		hours = 0;
		minutes = 0;
	}
	
	private boolean isValid(int hour, int minute) {
		if(hour >= 0 && hour <= 23 && minute >= 0 && minute <=59) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean isAM(String am) {
		if(am.equals("am")) {
			return true;
		} else {
			return false;
		}
	}
	
	public void setTime(int hour, int minute) {
		if(isValid(hour, minute)) {
			sethours(hour);
			setminutes(minute);
		} 
	}
	
	public void setTime(int hours, int minute, boolean isAM) {
		if(isAM) {
			if(hours >= 1 && hours <= 12) {
				if(hours == 12) {
					this.hours = 0;
					this.minutes = minute;
				} else {
					this.hours = hours;
					this.minutes = minute;
				}
			} 
		} else {
			if(hours >=1 && hours < 12) {
				this.hours = hours + 12;
				this.minutes = minute;
			} else {
				this.hours = hours;
				this.minutes = minute;
			}

		}
	}
	
	public String getTime24(int hours, int minutes) {
		String hour = "00";
		String minute = "00";
		
		hours = this.hours;
		minutes = this.minutes;

		if(hours >= 0 && hours <= 23) {
			if(hours <= 9) {
				hour = "0" + Integer.toString(hours);
			} else {
				hour = Integer.toString(hours);
			}
			this.hours = hours;
		}
		
		if(minutes >= 0 && minutes <=59) {
			if(minutes <= 9) {
				minute = "0" + Integer.toString(minutes);
			} else {
				minute = Integer.toString(minutes);
			}
			this.minutes = minutes;
		}

		String time = hour.concat(minute);
		return time;
	}
	
	public String getTime12(int hours, int minutes) {
		String hour;
		String minute;
		String result ="";
		
		
		if(hours == 0) {
			hour = Integer.toString(hours + 12);
			minute = Integer.toString(minutes);
			result = hour + ":" + minute + " AM";
		} else if(hours >=1 && hours <= 11) {
			hour = Integer.toString(hours);
			minute = Integer.toString(minutes);
			result = hour + ":" + minute + " AM";
		} else if(hours == 12) {
			hour = Integer.toString(hours);
			minute = Integer.toString(minutes);
			result = hour + ":" + minute + " PM";
		} else if(hours >= 13 && hours <= 23) {
			hour = Integer.toString(hours - 12);
			minute = Integer.toString(minutes);
			result = hour + ":" + minute + " PM";
		}
		
		return result;
	}
	
	public int gettime() {
		return time;
	}
	
	public int gethours() {
		return hours;
	}
	
	public int getminutes() {
		return minutes;
	}
	
	public void settime(int new_time) {
		this.time = new_time;
	}
	
	public void sethours(int new_hours) {
		this.hours = new_hours;
	}
	
	public void setminutes(int new_minutes) {
		this.minutes = new_minutes;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CH06_Time n = new CH06_Time();
		
		System.out.println("Create a default time");
		System.out.println("\t should be 0, 0: hours:  " + n.gethours() +  " minutes: " + n.getminutes());
		
		System.out.println("Set the time to 12, 12");
		n.setTime(12, 12);
		System.out.println("\t shoud be " + n.gethours()+ ", " + n.getminutes() + ":  hours: "+ n.gethours() + " minutes: " + n.getminutes());
		
		System.out.println("Trying to set time to -1, 12");
		n.setTime(-1, 12);
		System.out.println("\t shoud be " + n.gethours()+ ", " + n.getminutes() + ":  hours: "+ n.gethours() + " minutes: " + n.getminutes());
		
		System.out.println("Trying to set time to 12, -1");
		n.setTime(12, -1);
		System.out.println("\t shoud be " + n.gethours()+ ", " + n.getminutes() + ":  hours: "+ n.gethours() + " minutes: " + n.getminutes());
		
		System.out.println("Trying to set time to 24, 12");
		n.setTime(24, 12);
		System.out.println("\t shoud be " + n.gethours()+ ", " + n.getminutes() + ":  hours: "+ n.gethours() + " minutes: " + n.getminutes());
		
		System.out.println("Trying to set time to 12, 60");
		n.setTime(12, 60);
		System.out.println("\t shoud be " + n.gethours()+ ", " + n.getminutes() + ":  hours: "+ n.gethours() + " minutes: " + n.getminutes());
		
		System.out.println("Set the time to 8, 16 am");
		n.setTime(8, 16, n.isAM("am"));
		System.out.println("\t shoud be " + n.gethours()+ ", " + n.getminutes() + ":  hours: "+ n.gethours() + " minutes: " + n.getminutes());
		
		System.out.println("Set the time to 8, 16 pm");
		n.setTime(8, 16, n.isAM("pm"));
		System.out.println("\t shoud be " + n.gethours()+ ", " + n.getminutes() + ":  hours: "+ n.gethours() + " minutes: " + n.getminutes());
		
		System.out.println("Trying to set time to 0, 17 am");
		n.setTime(0, 17, n.isAM("am"));
		System.out.println("\t shoud be " + n.gethours()+ ", " + n.getminutes() + ":  hours: "+ n.gethours() + " minutes: " + n.getminutes());
		
		System.out.println("Trying to set time to 12, 17 am");
		n.setTime(12, 17, n.isAM("am"));
		System.out.println("\t shoud be " + n.gethours()+ ", " + n.getminutes() + ":  hours: "+ n.gethours() + " minutes: " + n.getminutes());
		
		System.out.println("Trying to set time to 0, 17 pm");
		n.setTime(0, 17, n.isAM("pm"));
		System.out.println("\t shoud be " + n.gethours()+ ", " + n.getminutes() + ":  hours: "+ n.gethours() + " minutes: " + n.getminutes());
		
		System.out.println("Trying to set time to 12, 17 pm");
		n.setTime(12, 17, n.isAM("pm"));
		System.out.println("\t shoud be " + n.gethours()+ ", " + n.getminutes() + ":  hours: "+ n.gethours() + " minutes: " + n.getminutes());
		
		System.out.println("Set the time to 12, 19 am");
		n.setTime(12, 19, n.isAM("am"));
		System.out.println("\t shoud be " + n.gethours()+ ", " + n.getminutes() + ":  hours: "+ n.gethours() + " minutes: " + n.getminutes());
	
		System.out.println("Set the time to 12, 19 pm");
		n.setTime(12, 19, n.isAM("pm"));
		System.out.println("\t shoud be " + n.gethours()+ ", " + n.getminutes() + ":  hours: "+ n.gethours() + " minutes: " + n.getminutes());
	
		System.out.println("\nTesting the constructors");
		System.out.println("Create the time 12, 19");
		n.setTime(12, 19);
		System.out.println("\tshould be " + n.gethours() + ", " + n.getminutes() + "pm:  " + n.getTime24(12,19) + " and " + n.getTime12(12,19));
		
		System.out.println("Create the time 12, 19 with the other constuctor");
		n.setTime(12, 19, n.isAM("pm"));
		System.out.println("\tshould be " + n.gethours() + ", " + n.getminutes() + "pm:  " + n.getTime24(12,19) + " and " + n.getTime12(12,19));
		
		System.out.println("Create the time 0, 19");
		n.setTime(0, 19);
		System.out.println("\tshould be " + n.gethours() + ", " + n.getminutes() + "am:  " + n.getTime24(n.gethours(),n.getminutes()) + " and " + n.getTime12(n.gethours(),n.getminutes()));
		
		System.out.println("Create the time 12, 19 with the other constuctor");
		n.setTime(12, 19, n.isAM("pm"));
		System.out.println("\tshould be " + n.gethours() + ", " + n.getminutes() + "pm:  " + n.getTime24(n.gethours(),n.getminutes()) + " and " + n.getTime12(n.gethours(),n.getminutes()));
	
		System.out.println("Create the time 3, 19");
		n.setTime(3, 19);
		System.out.println("\tshould be " + n.gethours() + ", " + n.getminutes() + "am:  " + n.getTime24(n.gethours(),n.getminutes()) + " and " + n.getTime12(n.gethours(),n.getminutes()));
		
		System.out.println("Create the time 3, 19 with the other constructor");
		n.setTime(3, 19, n.isAM("am"));
		System.out.println("\tshould be " + n.gethours() + ", " + n.getminutes() + "am:  " + n.getTime24(n.gethours(),n.getminutes()) + " and " + n.getTime12(n.gethours(),n.getminutes()));
		
		System.out.println("Create the time 15, 19");
		n.setTime(15, 19);
		System.out.println("\tshould be " + n.gethours() + ", " + n.getminutes() + "pm:  " + n.getTime24(n.gethours(),n.getminutes()) + " and " + n.getTime12(n.gethours(),n.getminutes()));
		
		System.out.println("Create the time 3, 19 with the other constructor");
		n.setTime(3, 19, n.isAM("pm"));
		System.out.println("\tshould be " + n.gethours() + ", " + n.getminutes() + "pm:  " + n.getTime24(n.gethours(),n.getminutes()) + " and " + n.getTime12(n.gethours(),n.getminutes()));
		
		
		
	}

}
