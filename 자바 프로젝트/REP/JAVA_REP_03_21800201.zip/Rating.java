public class Rating {
	
	private String name;
	private String movie_rate;
	private int terrible, bad, ok, good, great;
	private int error = 0;
	private double count = 0;
	private double average = 0;
	
	public void set_name(String name) {
		this.name = name;
	}
	
	public String get_name() {
		return name;
	}

	public void set_rating(String rate) {
		// TODO Auto-generated method stub
		this.movie_rate = rate;
	}
	
	public String get_rating() {
		return movie_rate;
	}
	
	public void addRating(int num) {
		// TODO Auto-generated method stub
		if(num == 1) {
			terrible++;
			count++;
		} else if(num == 2) {
			bad++;
			count++;
		} else if(num == 3) {
			ok++;
			count++;
		} else if(num == 4) {
			good++;
			count++;
		} else if(num == 5) {
			great++;
			count++;
		}
	}
	
	public void getAverage() {
			average = (1*terrible + 2*bad + 3*ok + 4*good + 5*great) / count;
			System.out.printf("The Average of this movie is %.2f !!!\n", average);
	}
}
