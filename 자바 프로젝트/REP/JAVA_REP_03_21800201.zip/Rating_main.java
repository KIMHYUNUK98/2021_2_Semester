import java.util.Scanner;

public class Rating_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		Rating rate1 = new Rating();
		Rating rate2 = new Rating();
		
		System.out.print("Write the Movie name: ");
		String name1 = s.nextLine().trim();
		rate1.set_name(name1);
		
		System.out.print("Input the MPAA rating(G, PG, PG-13, R): ");
		String ratemv1 = s.nextLine().trim();
		rate1.set_rating(ratemv1);
		
		for(int i = 0 ; i < 6 ; i++) {
			System.out.print("Rate " + name1 + " (1 ~ 5)> ");
			int num = s.nextInt();
			if(num >= 0 && num <= 5) {
				rate1.addRating(num);
			} else {
				System.out.println("There are no value of " + num + " Rating!!!");
				i--;
			}
		}
		
		s.nextLine();
		System.out.println("\n[Movie]");
		System.out.println("Move name = [" + name1 + "]");
		rate1.getAverage();
		System.out.println("MPAA of " + name1 + " is " + rate1.get_rating());
		
		
		System.out.print("\nWrite the Movie name: ");
		String name2 = s.nextLine().trim();
		rate2.set_name(name2);
		
		System.out.print("Input the MPAA rating(G, PG, PG-13, R): ");
		String ratemv2 = s.nextLine();
		rate2.set_rating(ratemv2);
		
		for(int i = 0 ; i < 6 ; i++) {
			System.out.print("Rate " + name2 + " (1 ~ 5)> ");
			int num = s.nextInt();
			if(num >= 0 && num <= 5) {
				rate2.addRating(num);
			} else {
				System.out.println("There are no value of " + num + " Rating!!!");
				i--;
			}
		}
		
		System.out.println("\n[Movie]");
		System.out.println("Move name = [" + name2 + "]");
		rate2.getAverage();
		System.out.println("MPAA of " + name2 + " is " + rate2.get_rating());
		
	}

}
