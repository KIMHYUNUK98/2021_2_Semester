
public class Student2 extends Person implements Comparable<Student2> {
	private int studentNumber;
	
	public Student2() {
		super();
		studentNumber = 0;
	}
	
	public Student2(String initialName, int initialStudentNumber) {
		super(initialName);
		studentNumber = initialStudentNumber;
	}
	
	public void reset(String newName, int newStudentNumber) {
		setName(newName);
		studentNumber = newStudentNumber;
	}
	
	public int getStudentNumber() {
		return studentNumber;
	}
	
	public void setStudentNumber(int newStudentNumber) {
		studentNumber = newStudentNumber;
	}
	
	public void writeOutput() {
		System.out.println("Name: " + getName());
		System.out.println("Student Number: " + studentNumber);
	}
	
	public boolean equals(Student2 otherStudent) {
		return this.hasSameName(otherStudent) && (this.studentNumber == otherStudent.studentNumber);
	}
	
	public String toString() {
		return "Name: " + getName() + "\nStudent Number: " + studentNumber;
	}
	
	public boolean equals(Object otherObject) {
		if(otherObject == null) 
			return false;
		else if(!(otherObject instanceof Student2))
			return false;
		else {
			Student2 otherStudent = (Student2)otherObject;
			return (this.hasSameName(otherStudent) && (this.studentNumber == otherStudent.studentNumber));
		}
	}

	@Override
	public int compareTo(Student2 o) {
		// TODO Auto-generated method stub
		if(this.studentNumber == o.studentNumber) {
			return 0;
		} else if(this.studentNumber < o.studentNumber) {
			return -1;
		} else {
			return 1;
		}
	}
}
