
public class Student3 extends Person implements Comparable<Student3> {
	private int studentNumber;
	
	public Student3() {
		super();
		studentNumber = 0;
	}
	
	public Student3(String initialName, int initialStudentNumber) {
		super(initialName);
		studentNumber = initialStudentNumber;
	}
	
	public void reset(String newName, int newStudentNumber) {
		setName(newName);
		studentNumber = newStudentNumber;
	}
	
	public int getStudentNumber() {
		return studentNumber;
	}
	
	public void setStudentNumber(int newStudentNumber) {
		studentNumber = newStudentNumber;
	}
	
	public void writeOutput() {
		System.out.println("Name: " + getName());
		System.out.println("Student Number: " + studentNumber);
	}
	
	public boolean equals(Student3 otherStudent) {
		return this.hasSameName(otherStudent) && (this.studentNumber == otherStudent.studentNumber);
	}
	
	public String toString() {
		return "Name: " + getName() + "\nStudent Number: " + studentNumber;
	}
	
	public boolean equals(Object otherObject) {
		if(otherObject == null) 
			return false;
		else if(!(otherObject instanceof Student3))
			return false;
		else {
			Student3 otherStudent = (Student3)otherObject;
			return (this.hasSameName(otherStudent) && (this.studentNumber == otherStudent.studentNumber));
		}
	}

	@Override
	public int compareTo(Student3 o) {
		// TODO Auto-generated method stub
		int ret = this.getName().compareTo(o.getName());
		return ret;
	}
}
