import java.util.Scanner;

public class Palindrome {
	
	public static boolean isPalindrome(char[] a, int used) {
		int len = used;
		
		for(int i = 0 ; i < len ; i++) {
			if(a[i] >= 'A' && a[i] <= 'Z') {
				a[i] = (char)(a[i] + ('a' - 'A'));
			}
		}

		for(int i = 0 ; i < (len - 1) / 2 ; i++) {
			if(a[i] == ' ') continue;
			if(a[i] != a[len - 1 - i]) {
				return false;
			}
			else {
				if(a[i] != a[len - 1 - i]) {
					return false;
				}
			}
		}
		return true;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Palindrome n = new Palindrome();
		Scanner s = new Scanner(System.in);
		String read;
		int used;
		boolean ispa;

		while(true) {
			System.out.println("This program will test whatever text");
			System.out.println("you enter to see if is a palindrome");
			System.out.println("(reads the same backwards and forwards)");
			System.out.println("\nEnter text (just letters and blanks, please.");
			
			read = s.nextLine();
			char[] arr = read.toCharArray();
			used = read.length();
			ispa = Palindrome.isPalindrome(arr, used); 
			if(ispa) {
				System.out.println("\nYES, the phrase is a palindrome!");
			} else {
				System.out.println("\nNO, the phrase is NOT a palindrome.");
				
			}
			
			System.out.println("Continue?? (YES: 1, NO: 0) > ");
			int flag = s.nextInt();
			s.nextLine();
			if(flag != 1) {
				System.out.printf("System Exit\n");
				break;
			}
		}
		
	}

}
