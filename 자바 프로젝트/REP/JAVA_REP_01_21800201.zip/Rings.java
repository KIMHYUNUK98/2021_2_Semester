import javafx.application.Application;
import javafx.scene.canvas.Canvas;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.stage.Stage;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.shape.ArcType;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class Rings extends Application {

	public static final int WINDOW_WIDTH = 400;
	public static final int WINDOW_HEIGHT = 300;
	
	public static final int RING_WIDTH = 15;
	public static final int RING_HEIGHT = 15;
	public static final int RING_DIAMETER = 80;
	public static final int RING_DISTANCE_WIDTH = 95;
	public static final int RING_DISTACNE_HEIGHT = 60;
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		launch(args);
	}	

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		Group root = new Group();
		Scene scene = new Scene(root);
      
		Canvas canvas = new Canvas(WINDOW_WIDTH,WINDOW_HEIGHT);
		GraphicsContext gc = canvas.getGraphicsContext2D();
		
		int yOffset = 50;
		int xOffset = 45;
      

		gc.setStroke(Color.BLUE);
        gc.strokeOval(RING_WIDTH, RING_HEIGHT, RING_DIAMETER, RING_DIAMETER);
        
        gc.setStroke(Color.BLACK);
        gc.strokeOval(RING_WIDTH + RING_DISTANCE_WIDTH, RING_HEIGHT, RING_DIAMETER, RING_DIAMETER);
        
        gc.setStroke(Color.RED);
        gc.strokeOval(RING_WIDTH + 2 * RING_DISTANCE_WIDTH, RING_HEIGHT, RING_DIAMETER, RING_DIAMETER);
        
        gc.setStroke(Color.YELLOW);
        gc.strokeOval(RING_WIDTH + xOffset, RING_HEIGHT + yOffset, RING_DIAMETER, RING_DIAMETER);
        
        gc.setStroke(Color.GREEN);
        gc.strokeOval(RING_WIDTH + xOffset + RING_DISTANCE_WIDTH, RING_HEIGHT + yOffset, RING_DIAMETER, RING_DIAMETER);
      
      
      
		root.getChildren().add(canvas);
		primaryStage.setTitle("Rings in JavaFX");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
   	
}