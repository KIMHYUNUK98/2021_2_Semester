import java.util.Scanner;
import java.util.StringTokenizer;

public class MonthDay {

	public static void main(String[] args) throws MonthException, DayException {
		// TODO Auto-generated method stub
		ChangeMonth ch = new ChangeMonth();
		Scanner s = new Scanner(System.in);
		String num = " ";
		char again;
		
		while(true) {
			try {
				System.out.println("Enter date in numerical month/day format: ");
				num = s.next();
				StringTokenizer st = new StringTokenizer(num, "/");
				
				int test1 = Integer.parseInt(st.nextToken());
				int test2 = Integer.parseInt(st.nextToken());
				
				ch.setMonth(test1);
				ch.setDay(test2);
				
				if( test1 < 1 || test1 > 12) {
					System.out.print("\n" + test1 + " is in invalid: ");
					throw new MonthException("month number must be from 1 to 12.\n");
				}
				else {
					if(test1 == 2) {
						if(test2 < 1 || test2 > 28)
							throw new DayException("1 through 28 only, please.\n");
					}
					else if(test1 == 1 || test1 == 3 || test1 == 5 || test1 == 7 || test1 == 8 || test1 == 10 || test1 == 12) {
						if(test2 < 1 || test2 > 31)
							throw new DayException("1 through 31 only, please.\n");
					}
					else if(test1 == 4 || test1 == 6 || test1 == 8 || test1 == 9 || test1 == 11){
						if(test2 < 1 || test2 > 30)
							throw new DayException("1 through 30 only, please.\n");
					}
					
					ch.result();
				}
			} catch(DayException e) {
				System.out.println(e.getMessage());
				System.out.println("You have entered an invalid day for month number " + ch.getMonth());
			} catch(MonthException e) {
				System.out.println(e.getMessage());
			}
			
			System.out.println("Again? (y/n)");
			again = s.next().charAt(0);
			if(again == 'y') {
				continue;
			} else if(again == 'n') {
				break;
			}
			
			
		}
	}

}
