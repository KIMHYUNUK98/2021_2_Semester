
public class ChangeMonth {
	private int month;
	private int day;
	private String ch_month;
	
	public void setMonth(int month) {
		this.month = month;
	}
	
	public int getMonth() {
		return this.month;
	}
	
	public void setDay(int day) {
		this.day = day;
	}
	
	public int getDay() {
		return this.day;
	}
	
	public void result() {
		if(getMonth() == 1) {
			ch_month = "January";
		} else if(getMonth() == 2) {
			ch_month = "Feburary";
		} else if(getMonth() == 3) {
			ch_month = "March";
		} else if(getMonth() == 4) {
			ch_month = "April";
		} else if(getMonth() == 5) {
			ch_month = "May";
		} else if(getMonth() == 6) {
			ch_month = "June";
		} else if(getMonth() == 7) {
			ch_month = "July";
		} else if(getMonth() == 8) {
			ch_month = "August";
		} else if(getMonth() == 9) {
			ch_month = "Setember";
		} else if(getMonth() == 10) {
			ch_month = "Octobor";
		} else if(getMonth() == 11) {
			ch_month = "November";
		} else if(getMonth() == 12) {
			ch_month = "December";
		} 
		System.out.println(getMonth() + "/" + getDay() + " is " + ch_month + " " + getDay());
	}
	
	
}
