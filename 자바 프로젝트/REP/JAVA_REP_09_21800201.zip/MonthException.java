
public class MonthException extends Exception {

	public MonthException() {}
	public MonthException(String s) {
		super(s);
	}
	
}
