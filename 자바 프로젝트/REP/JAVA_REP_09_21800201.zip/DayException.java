
public class DayException extends Exception{

	public DayException() {}
	public DayException(String s) {
		super(s);
	}
}
