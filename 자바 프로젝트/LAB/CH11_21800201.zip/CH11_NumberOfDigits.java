import java.util.*;

public class CH11_NumberOfDigits {
	
	private static int count = 1;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Enter a signed integer: ");
		int number = keyboard.nextInt();
		System.out.println(number + " contains " + numberOfDigits(number) + " digits.");
	}
	
	public static int numberOfDigits(int n) {
		int ab = Math.abs(n);
		
		if(ab / 10 != 0) {
			return (numberOfDigits(ab / 10) + 1);
		} else if(ab / 10 == 0 && ab % 10 < 10) {
			return 1;
		} else
			return 0;
	}

}
