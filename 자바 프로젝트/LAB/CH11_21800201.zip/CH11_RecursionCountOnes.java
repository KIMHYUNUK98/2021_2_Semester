import java.util.*;

public class CH11_RecursionCountOnes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a nonnegative number: ");
		Scanner s = new Scanner(System.in);
		int number = s.nextInt();
		System.out.println(number + " contains " + numberOfOnes(number) + " ones.");
	}
	
	public static int numberOfOnes(int n) {
		if(n == 1) {
			return 1;
		}
		else if(n < 10) {
			return 0;
		}
		else if(n % 10 == 1) {
			return (numberOfOnes(n/10) + 1);
		}
		else {
			return (numberOfOnes(n/10));
		}
	}

}
