public class CH05_MyPassFail {
	
	private String name;
	private int score;
	
	public void writeoutput() {
		String grade;
		if(score > 50)
			grade = "pass";
		else 
			grade = "fail";
	System.out.println(name + ": " + score + ": " + grade);	
	}
	
	public int getScore() {
		return score;
	}
	
	public String getName() {
		return name;
	}
	
	public void setdata(String s_name, int s_score) {
		this.name = s_name;
		this.score = s_score;
	}
	
	public boolean equals(CH05_MyPassFail student2) {
		if(this == student2)
			return true;
		else 
			return false;
	}

	public void copyFrom(CH05_MyPassFail student2) {
		// TODO Auto-generated method stub
		this.name = student2.name;
		this.score = student2.score;
	}

	public static void identifyOrSameValue(CH05_MyPassFail student1, CH05_MyPassFail student2) {
		// TODO Auto-generated method stub
		if(student1.equals(student2) && student1.score == student2.score && student1.name.equals(student1.name)) {
			System.out.println("Student1 and Student2 are Same object, Same HashCode");
			System.out.println("Student1 and Student2 have Same state, Same value of instance variable");
		}
		else if(student1.equals(student2) && student1.score != student2.score && !student1.name.equals(student1.name)) {
			System.out.println("Student1 and Student2 are Same object, Same HashCode");
			System.out.println("Student1 and Student2 have different value of instance variables");
		}
		else if(!student1.equals(student2) && student1.score == student2.score && student1.name.equals(student1.name)) {
			System.out.println("Student1 and Student2 are different object, different Hashcode");
			System.out.println("Student1 and Student2 have Same state, Same value of instance variable");
		}
		else {
			System.out.println("Student1 and Student2 are different object, different Hashcode");
			System.out.println("Student1 and Student2 have different value of instance variables");
		}
	}
}
