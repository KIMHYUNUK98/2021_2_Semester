public class CH05_MyCalculator2_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CH05_MyCalculator2 myCal2 = new CH05_MyCalculator2();
		myCal2.getinput();
		myCal2.printresult();
	}
}
