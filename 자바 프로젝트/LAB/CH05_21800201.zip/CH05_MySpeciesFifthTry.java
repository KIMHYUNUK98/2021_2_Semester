import java.util.Scanner;

public class CH05_MySpeciesFifthTry {
	
	private String name;
	private int population;
	private double growthRate;

	public void readInput() {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("What is the species' name?");
		name = s.nextLine();
		
		System.out.println("What is the population of the species?");
		population = s.nextInt();
		
		System.out.println("Enter growth rate (% increase per year):");
		growthRate = s.nextDouble();
	}

	public void writeOutput() {
		// TODO Auto-generated method stub
		System.out.println("Name = " + name);
		System.out.println("Population = " + population);
		System.out.println("Growth rate = " + growthRate + "%");
	}

	public int predictPopulation(int numberOfYears) {
		// TODO Auto-generated method stub
		int result = 0;
		double populationAmount = population;
		int count = numberOfYears;
		while((count > 0) && (populationAmount > 0))
		{
			populationAmount = (populationAmount + (growthRate / 100) * populationAmount);
			count--;
		}
		
		if(populationAmount > 0)
			result = (int)populationAmount;
		
		return result;
	}
	
	public void setSpecies(String name, int population, double growthRate) {
		this.name = name;
		if(population >= 0)
			this.population = population;
		else
		{
			System.out.println("ERROR: using a negative population.");
			System.exit(0);
		}
		this.growthRate = growthRate;
	}
	
	public String getName() {
		return name;
	}
	
	public int getPopulation() {
		return population;
	}
	
	public double getGrowthRate() {
		return growthRate;
	}
	
	public void setName(String name) {
		// TODO Auto-generated method stub
		this.name = name;
	}

	public void setPopulation(int population) {
		// TODO Auto-generated method stub
		if(population >= 0)
			this.population = population;
		else
		{
			System.out.println("ERROR: using a negative population.");
			System.exit(0);
		}
	}

	public void setGrowthRate(double growthRate) {
		// TODO Auto-generated method stub
		this.growthRate = growthRate;
	}
}
