import java.util.Scanner;

public class CH07_Matrix {
	public static void makeMatrix(int[][] a) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		for(int i = 0 ; i < a.length ; i++) {
			for(int j = 0 ; j < a[0].length ; j++) {
				a[i][j] = i + j;
			}
		}
	}

	public static void printMatrix(int[][] a) {
		// TODO Auto-generated method stub
		for(int i = 0 ; i < a.length ; i++) {
			for(int j = 0 ; j < a[0].length ; j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
	}

}
