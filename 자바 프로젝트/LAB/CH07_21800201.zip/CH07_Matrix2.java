public class CH07_Matrix2 {

	public static void makeMatrix2(int[][] a) {
		// TODO Auto-generated method stub
		int count = 1;
		
		for(int i = 0 ; i < a.length ; i++) {
			for(int j = 0 ; j < a[0].length ; j++) {
				a[i][j] = count++;
			}
		}
		
	}

	public static void addition(int[][] a, int[][] b) {
		// TODO Auto-generated method stub
		System.out.println("\nMatrix addition is ..");
		
		for(int i = 0 ; i < a.length ; i++) {
			for(int j = 0 ; j < a[0].length ; j++) {
				int add = a[i][j] + b[i][j];
				System.out.print(add + " ");
			}
			System.out.println("");
		}
	}

	public static void subtraction(int[][] a, int[][] b) {
		// TODO Auto-generated method stub
		System.out.println("\nMatrix subtraction is ..");
		
		for(int i = 0 ; i < a.length ; i++) {
			for(int j = 0 ; j < a[0].length ; j++) {
				int sub = a[i][j] - b[i][j];
				System.out.print(sub + " ");
			}
			System.out.println("");
		}
		
	}

	public static void multiplication(int[][] a, int[][] b) {
		// TODO Auto-generated method stub
		System.out.println("\nMatrix multiplication is ..");
		int mult = 0;
		
		for(int i = 0 ; i < a.length ; i++) {
			for(int j = 0 ; j < a[0].length ; j++) {
				for(int k = 0 ; k < b[0].length ; k++) {
					mult += a[i][k] * b[k][j];
				}
				System.out.print(mult + " ");
				mult = 0;
			}
			System.out.println("");
		}
	}

}
