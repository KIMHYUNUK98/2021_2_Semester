public class CH07_Decreasing {
	
	public static boolean isStrictlyDecreasing(int[] dc) {
		for(int i = 0 ; i < dc.length - 1 ; i++) {
			if(dc[i] < dc[i+1])
				return false;
		}
		return true;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr1 = { 1, 2, 4, 5, 7};
		int[] arr2 = { 5, 2, 3, 9, 9};
		int[] arr3 = { 15, 13, 12, 9, 4};
		int[] arr4 = { 28, 23, 13, 12, 2};
		int[] arr5 = { 33, 44, 22, 55, 11};
		
		System.out.println("Array1 (1,2,3,5,7) is not in decreasing order, should be FALSE: " + isStrictlyDecreasing(arr1));
		System.out.println("Array2 (5,2,3,9,9) is not decreasing, should be FALSE: " + isStrictlyDecreasing(arr2));
		System.out.println("Array3 (15,13,12,9,4) is decreasing, should be TRUE: " + isStrictlyDecreasing(arr3));
		System.out.println("Array4 (28,23,13,12,2) is decreasing, should be TRUE: " + isStrictlyDecreasing(arr4));
		System.out.println("Array5 (33,44,22,55,11) is not decreasing order, should be FALSE: " + isStrictlyDecreasing(arr5));
		
	}

}
