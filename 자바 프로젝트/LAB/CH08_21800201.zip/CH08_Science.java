
public class CH08_Science extends CH08_Book {

	private String science;
	
	CH08_Science(String arr1, String arr2) {
		super(arr1);
		setScience(arr2);
	}
	
	public String getScience() {
		return science;
	}
	
	public void setScience(String science) {
		this.science = science;
	}
	
	public String toString() {
		return "Publisher: " + science;
	}
	
	public void print() {
		System.out.println("<<<Science>>>");
		System.out.println(super.getOwnId());
		System.out.println(super.toString());
		System.out.println(toString());
	}
}
