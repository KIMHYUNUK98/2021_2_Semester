
public class CH08_ClassFriend extends CH08_SchoolFriend {

	private String subject;
	
	CH08_ClassFriend(String arr1, String arr2) {
		super(arr1);
		setSubject(arr2);
	}
	
	public String getSubject() {
		return this.subject;
	}
	
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	public void whatfriend() {
		super.whatfriend();
		System.out.println("in " + getSubject());
	}
	
	
}
