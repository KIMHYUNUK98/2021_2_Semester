
public class CH08_History extends CH08_Book {
	
	private String history;
	
	CH08_History(String arr1, String arr2) {
		super(arr1);
		setHistory(arr2);
	}
	
	public String getHistory() {
		return this.history;
	}
	
	public void setHistory(String history) {
		this.history = history;
	}
	
	public String toString() {
		return "Author: " + history;
	}

	public void print() {
		System.out.println("<<<History>>>");
		System.out.println(super.getOwnId());
		System.out.println(super.toString());
		System.out.println(toString());
	}
}
