
public class CH08_Doctor extends CH08_Person {
	
	private String name;
	private String specialty;
	private double fee;
	
	CH08_Doctor() {
		super();
		setOfficeFee(150.0);
		setSpecialty("None given");
	}
	
	CH08_Doctor(String name) {
		super(name);
		setOfficeFee(150.0);
		setSpecialty("None given");
	}
	
	CH08_Doctor(String name, double fee) {
		super(name);
		setOfficeFee(fee);
		setSpecialty("None given");
	}
	
	CH08_Doctor(String name, String specialty) {
		super(name);
		setOfficeFee(150);
		setSpecialty(specialty);
	}
	
	CH08_Doctor(String name, double fee, String specialty) {
		super(name);
		setOfficeFee(fee);
		setSpecialty(specialty);
	}
	
	public void setName(String name) {
		super.setName(name);
	}
	
	public String getName() {
		return super.getName();
	}
	
	public void setOfficeFee(double fee) {
		this.fee = fee;
	}
	
	public double getOfficeFee() {
		return this.fee;
	}
	
	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}
	
	public String getSpecialty() {
		return this.specialty;
	}
	
	public void writeName() {
		super.writeOutput();
	}
	
	public void writeOfficeFee() {
		System.out.println("Office Fee: " + "$"  + getOfficeFee());
	}
	
	public void writeSpecialty() {
		System.out.println("Specialty: " + getSpecialty());
	}
	
	public void set(String name, double fee, String specialty) {
		super.setName(name);
		setOfficeFee(fee);
		setSpecialty(specialty);
	}
	
	public void writeOutput() {
		super.writeOutput();
		System.out.println("Office: " + "$" + getOfficeFee());
		System.out.println("Specialty: " + getSpecialty());
	}
	
	
	public boolean equals(CH08_Doctor otherObject) {
		boolean isEqual = false;
		if ((otherObject instanceof CH08_Doctor) && (otherObject != null)) {
			CH08_Doctor otherDoctor = (CH08_Doctor) otherObject;
			isEqual = (this.hasSameName(otherDoctor)) && ((this.fee == otherDoctor.fee)) && ((this.specialty).equals(otherDoctor.specialty));
		}
		
		return isEqual;
	}
}
	
