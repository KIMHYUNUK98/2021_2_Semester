
public class CH08_Book {

	private String book_name;
	private static int id = 0;
	private int own_id;
	
	CH08_Book(String arr) {
		setBookName(arr);
		increaseID();
		setOwnId(id);
	}
	
	public String getBookName() {
		return this.book_name;
	}
	
	public void setBookName(String bookName) {
		this.book_name = bookName;
	}
	
	public int getOwnId() {
		return this.own_id;
	}
	
	public void setOwnId(int id) {
		this.own_id = id;
	}
	
	public static void increaseID() {
		id++;
	}
	
	public String toString() {
		return "Book Name: " + book_name;
	}
	
	public void print() {
		System.out.println("<<<BOOK>>>");
		System.out.println(getOwnId());
		System.out.println(toString());
	}
}
