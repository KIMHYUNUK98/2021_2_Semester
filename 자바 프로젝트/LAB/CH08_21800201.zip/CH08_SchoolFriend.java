
public class CH08_SchoolFriend extends CH08_Friend {
	private String school;
	
	CH08_SchoolFriend(String arr) {
		setSchool(arr);
	}
	
	public String getSchool() {
		return this.school;
	}
	
	public void setSchool(String school) {
		this.school = school;
	}
	
	public void whatfriend() {
		super.whatfriend();
		System.out.println("in " + getSchool());
	}
}
