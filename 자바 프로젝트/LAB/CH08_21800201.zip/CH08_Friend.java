
public class CH08_Friend {
	private String friend;
	
	CH08_Friend() {
		setFriend("We are friends.");
	}
	
	public String getFriend() {
		return this.friend;
	}
	
	public void setFriend(String friend) {
		this.friend = friend;
	}
	
	public void whatfriend() {
		System.out.println(getFriend());
	}
}
