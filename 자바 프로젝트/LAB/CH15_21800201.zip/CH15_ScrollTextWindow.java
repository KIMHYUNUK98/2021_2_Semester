import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;

public class CH15_ScrollTextWindow extends JFrame implements ActionListener{
	
	public final int WIDTH = 500;
	public final int HEIGHT = 400;
	static int count = 1;
	
	JPanel panel = new JPanel(new GridLayout(1,2));
	JPanel panel2 = new JPanel();
	JTextField theText = new JTextField(20);
	JButton button1 = new JButton("Append the count");
	JButton button2 = new JButton("Put in a return");
	JTextArea area = new JTextArea(10, 40);
	JScrollPane scroll = new JScrollPane(area);
	
	public CH15_ScrollTextWindow() {
		setSize(WIDTH, HEIGHT);
		setTitle("Window Creater");
		Container content = getContentPane();
		content.setLayout(new BorderLayout());
		
		panel.add(button1, BorderLayout.CENTER);
		button1.addActionListener(this);
		panel.add(button2, BorderLayout.CENTER);
		button2.addActionListener(this);
		
		panel2.setBackground(Color.GREEN);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		panel2.add(scroll);
		
		content.add(panel, BorderLayout.NORTH);
		content.add(panel2, BorderLayout.CENTER);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == button1) {
			area.append(Integer.toString(count) + " ");
			count++;
		} else if(e.getSource() == button2) {
			area.append("\n");
		}
	}
}
