import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;

public class CH15_RecorderWindow extends JFrame implements ActionListener {
	
	public static final int WIDTH = 400;
	public static final int HEIGHT = 200;
	
	JPanel panel = new JPanel(new BorderLayout());
	JTextField theText = new JTextField(20);
	JButton button = new JButton("Create Window");
	JTextArea area = new JTextArea();
	
	public CH15_RecorderWindow() {
		setSize(WIDTH, HEIGHT);
		setTitle("Window Creater");
		Container content = getContentPane();
		content.setBackground(Color.WHITE);
		content.setLayout(new BorderLayout());
		
		theText.addActionListener(this);
		panel.add(theText, BorderLayout.WEST);
		
		button.addActionListener(this);
		panel.add(button, BorderLayout.EAST);
		content.add(panel, BorderLayout.NORTH);
		
		content.add(area, BorderLayout.CENTER);
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == button) {
			NameWindow name = new NameWindow(theText.getText());
		}
	}
	
	private class FloatingWindowHandler extends WindowAdapter {
		
		@Override
		public void windowClosing(WindowEvent e) {
			area.append("Disposed of window " + theText.getText() + "\n");
		}
		
	}
	
	private class NameWindow extends JFrame {
		
		public NameWindow(String myName) {
			Container s = getContentPane();
			setSize(400,200);
			setTitle(myName);
			FloatingWindowHandler exit = new FloatingWindowHandler();
			addWindowListener(exit);
			setVisible(true);
		}
	}
}
