// �й�: 21800201 �̸�: ������
import java.util.*;
public class KIMHYUNUK 
{
	public static void main(String[] args) 
	{
	System.out.println("Name : KimHyunUk");
	System.out.println("University : Handong Global University");
	System.out.println("Student Number 21800201");
	}
}
