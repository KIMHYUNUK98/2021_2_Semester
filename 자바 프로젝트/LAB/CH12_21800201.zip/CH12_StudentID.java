import java.util.*;

public class CH12_StudentID {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		HashMap<Integer, ArrayList<String>> students = new HashMap<Integer, ArrayList<String>>();
		ArrayList<String> name1 = new ArrayList<String>();
		ArrayList<String> name2 = new ArrayList<String>();
		ArrayList<String> name3 = new ArrayList<String>();
		ArrayList<String> name4 = new ArrayList<String>();
		
		System.out.println("Enter data in the format: ID Course Num");
		System.out.println("Enter -1 to end.");
		
		while(true) {
			int num = s.nextInt();
			if(num == -1) break;
			String arr = s.next();
			
			if(num == 1) {
				name1.add(arr);
				students.put(num, name1);
			}
			else if(num == 2) {
				name2.add(arr);
				students.put(num, name2);
			}
			else if(num == 3) {
				name3.add(arr);
				students.put(num, name3);
			}
			else if(num == 4) {
				name4.add(arr);
				students.put(num, name4);
			}
		}

		for(int i = 1 ; i <= students.size(); i++) {
			System.out.println("Student: " + i);
			System.out.println(students.get(i).toString().replaceAll("\\[|\\]", ""));
		}
	}

}
