import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;


public class CH12_NumIntegers {

	HashSet<Integer> hashset = new  HashSet<Integer>();
	
	public void readdata(String filename) {
		// TODO Auto-generated method stub
		try {
			File fp = new File("./src/" + filename);
			System.out.println();
			Scanner sc = new Scanner(fp);
			
			while(sc.hasNextLine()) {
				hashset.add(sc.nextInt());
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public int getNumIntegers() {
		// TODO Auto-generated method stub
		return hashset.size();
	}

	public void printIntegers() {
		// TODO Auto-generated method stub
		Iterator iter = hashset.iterator();
		while(iter.hasNext()) {
			System.out.print(iter.next() + " ");
		}
	}

}
