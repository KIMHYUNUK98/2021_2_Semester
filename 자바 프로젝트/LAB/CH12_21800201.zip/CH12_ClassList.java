import java.util.ArrayList;

public class CH12_ClassList {
	
	ArrayList<String> arr = new ArrayList<String>();

	public void Print() {
		// TODO Auto-generated method stub
		System.out.println("\nList of classes");
		
		for(int i = 0 ; i < arr.size(); i++) {
			System.out.print("Class " + (i+1) + ": ");
			System.out.println(arr.get(i));
		}
	}

	public void add(String s) {
		// TODO Auto-generated method stub
		arr.add(s);
	}

}
