import java.util.Scanner;

public class CH09_MessageTooLongExceptionDemo {

		private static String inputLine;
		private static int linelength;
			
		public static void main(String[] args) throws Exception {
			// TODO Auto-generated method stub
			Scanner keyboard = new Scanner(System.in);
			char repeat;
			
			while(true) {
				System.out.println("\nEnter a line of text up to 20 characters long.");
				inputLine = keyboard.next();
				linelength = inputLine.length();	
				
				CH09_MessageTooLongException b = new CH09_MessageTooLongException(inputLine, linelength);
			
				repeat = keyboard.next().charAt(0);
				if(repeat == 'y') {
					continue;
				} else {
					break;
				}
			}
	}

}
