
public class CH09_MessageTooLongException {
	
	private String line;
	private int length;
	
	public String getLine() {
		return this.line;
	}
	
	public void setLine(String line) {
		this.line = line;
	}
	
	public int getLength() {
		return this.length;
	}
	
	public void setLength(int length) {
		this.length = length;
	}
	
	CH09_MessageTooLongException(String line, int length) {
		this.line = line;
		this.length = length;
		
		try {
			if(getLength() > 20) {
				throw new Exception("Message too Long!\n");
			} else {
				System.out.print("You entered " + length + " characters, which is an acceptable length\nDo again?(y for Yes)\n");
			}
		} catch(Exception e){
			System.out.println(e.getMessage());
			System.out.println("Do Again?(y for Yes)");
		}
	}
		

}
