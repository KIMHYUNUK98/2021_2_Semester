
public class CH09_SpeedLim  {
	
	private int limit;
	private int speed;
	
	public int getLimit() {
		return this.limit;
	}
	
	public void setLimit(int limit) {
		this.limit = limit;
	}
	
	public int getSpeed() {
		return this.speed;
	}
	
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
	CH09_SpeedLim(int limit, int speed) {
		this.limit = limit;
		this.speed = speed;
	}

	public void SpeedWarning() {
		try {
			if(getSpeed() > 100) {
				throw new Exception("Speed Limit 100km exceeded!\nYou are being fined.");
			} else {
				System.out.println("You are a law abiding\ncitizen!");
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Your currend speed: " + getSpeed());
		
	}
}
