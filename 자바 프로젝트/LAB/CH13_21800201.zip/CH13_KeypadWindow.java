import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CH13_KeypadWindow extends JFrame implements ActionListener {
	JFrame window = new JFrame();
	JPanel panel = new JPanel();
	JTextArea theText = new JTextArea();
	
	JButton button1 = new JButton("1");
	JButton button2 = new JButton("2");
	JButton button3 = new JButton("3");
	JButton button4 = new JButton("4");
	JButton button5 = new JButton("5");
	JButton button6 = new JButton("6");
	JButton button7 = new JButton("7");
	JButton button8 = new JButton("8");
	JButton button9 = new JButton("9");
	JButton button10 = new JButton("*");
	JButton button11 = new JButton("0");
	JButton button12 = new JButton("#");
	
	
	public static int WIDTH = 600;
	public static int HEIGHT = 300;
	
	public CH13_KeypadWindow() {
		Container contentPane = getContentPane();
		contentPane.setBackground(Color.WHITE);
		contentPane.setLayout(new BorderLayout());
		
		setSize(WIDTH, HEIGHT);
		setTitle("Keypad");

		panel.setLayout(new GridLayout(4,3));
		
		panel.add(button1);
		button1.addActionListener(this);
		panel.add(button2);
		button2.addActionListener(this);
		panel.add(button3);
		button3.addActionListener(this);
		panel.add(button4);
		button4.addActionListener(this);
		panel.add(button5);
		button5.addActionListener(this);
		panel.add(button6);
		button6.addActionListener(this);
		panel.add(button7);
		button7.addActionListener(this);
		panel.add(button8);
		button8.addActionListener(this);
		panel.add(button9);
		button9.addActionListener(this);
		panel.add(button10);
		panel.add(button11);
		button11.addActionListener(this);
		panel.add(button12);
		
		contentPane.add(panel);		
		contentPane.add(theText, BorderLayout.SOUTH);
	}
	
	public void actionPerformed(ActionEvent e) {
		Container contentPane = getContentPane();
		
		if(e.getSource() == button1) {
			theText.append("1");
		} else if(e.getSource() == button2) {
			theText.append("2");
		} else if(e.getSource() == button3) {
			theText.append("3");
		} else if(e.getSource() == button4) {
			theText.append("4");
		} else if(e.getSource() == button5) {
			theText.append("5");
		} else if(e.getSource() == button6) {
			theText.append("6");
		} else if(e.getSource() == button7) {
			theText.append("7");
		} else if(e.getSource() == button8) {
			theText.append("8");
		} else if(e.getSource() == button9) {
			theText.append("9");
		} else if(e.getSource() == button11) {
			theText.append("0");
		} 
	}
	
}
