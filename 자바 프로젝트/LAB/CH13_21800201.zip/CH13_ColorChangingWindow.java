import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CH13_ColorChangingWindow extends JFrame implements ActionListener {
	
	JFrame window = new JFrame();
	
	public static int WIDTH = 500;
	public static int HEIGHT = 400;
	public String name = "WHITE";

	public CH13_ColorChangingWindow() {
		setSize(WIDTH, HEIGHT);
		
		//addWindowListner(new WindowDestroyer());
		setTitle("Color Changing Window");
		Container contentPane = getContentPane();
		contentPane.setBackground(Color.WHITE);
		contentPane.setLayout(new BorderLayout());
		
		JButton changeButton = new JButton(name);	
		changeButton.addActionListener(this);
	
		contentPane.add(changeButton, BorderLayout.NORTH);
	}
	
	public void actionPerformed(ActionEvent e) {
		Container contentPane = getContentPane();
		
		if(name.equals("WHITE")) {
			contentPane.setBackground(Color.BLUE);
			name = "BLUE";
		} else if(name.equals("BLUE")) {
			contentPane.setBackground(Color.RED);
			name = "RED";
		} else if(name.equals("RED")) {
			contentPane.setBackground(Color.WHITE);
			name = "WHITE";
		} 
	}
}
