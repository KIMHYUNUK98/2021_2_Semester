
public class CH06b_EnumTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CH06b_Suit s = CH06b_Suit.FRI;
		System.out.println("s.ordinal() = " + s.ordinal());
		
		System.out.println("s.compareTo(CH06b_Suit.WED) = " + s.compareTo(CH06b_Suit.WED));
		
		System.out.println("s.toString() = " + s.toString());
		System.out.println("s.getColor() = " + s.getColor());
		
		for(CH06b_Suit test : CH06b_Suit.values()) {
			System.out.println(test + " " + test.getColor());
		}
	}

}
