
public class CH06a_Neo {
	static int howmany = 0;
	String emoticon;
	
	public static int gethowmany() {
		return howmany;
	}
	
	public CH06a_Neo(String emoticon) {
		this.emoticon = emoticon;
		howmany++;
	}
	
	public void emoticonStyle() {
		System.out.println("Neo is " + this.emoticon + ".");
	}
}
