import javafx.application.Application;
import javafx.scene.canvas.Canvas;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.stage.Stage;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.shape.ArcType;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class CH04_MyMultipleFaces extends Application {

   public static final int WINDOW_WIDTH = 700;
   public static final int WINDOW_HEIGHT = 400;
   
   public static final int FACE_DIAMETER = 50;
   public static final int X_FACEO = 10;
   public static final int Y_FACEO = 5;
   
   public static final int EYE_WIDTH = 5;
   public static final int EYE_HEIGHT = 10;
   public static final int X_RIGHT_EYEO = 20;
   public static final int Y_RIGHT_EYEO = 15;
   public static final int X_LEFT_EYEO = 45;
   public static final int Y_LEFT_EYEO = Y_RIGHT_EYEO;
   
   public static final int NOSE_DIAMETER = 5;
   public static final int X_NOSEO = 32;
   public static final int Y_NOSEO = 25;
   
   public static final int MOUTH_WIDTH = 30;
   public static final int MOUTH_HEIGHTO = 0;
   public static final int X_MOUTHO = 20;
   public static final int Y_MOUTHO = 35;
   public static final int MOUTH_START_ANGLE = 180;
   public static final int MOUTH_EXTENT_ANGLE = 180;
   
   public static void main(String[] args) {
      // TODO Auto-generated method stub
      launch(args);
   }

   
   @Override
   public void start(Stage primaryStage) throws Exception
   {
      Group root = new Group();
      Scene scene = new Scene(root);
      
      Canvas canvas = new Canvas(WINDOW_WIDTH,WINDOW_HEIGHT);
      GraphicsContext gc = canvas.getGraphicsContext2D();
      
      int i, xOffset, yOffset;
      
      for(i = 0 ; i <= 8 ; i++) 
      {
         xOffset = 50 * i;
         yOffset = 30 * i;
         
         if(i % 3 == 0)
         {
            gc.setFill(Color.YELLOW);
            gc.fillOval(X_FACEO + xOffset, Y_FACEO + 30 * i,FACE_DIAMETER, FACE_DIAMETER);
         } else if(i % 3 == 1) {
             gc.setFill(Color.GREEN);
             gc.fillOval(X_FACEO + xOffset, Y_FACEO + 30 * i,FACE_DIAMETER, FACE_DIAMETER);
          } else if(i % 3 == 2) {
              gc.setFill(Color.GRAY);
              gc.fillOval(X_FACEO + xOffset, Y_FACEO + 30 * i,FACE_DIAMETER, FACE_DIAMETER);
           }
        
         // setFill -> setStroke
         gc.setStroke(Color.BLACK);
         gc.strokeOval(X_FACEO + xOffset, Y_FACEO + yOffset,FACE_DIAMETER, FACE_DIAMETER);
         
         // Draw eyes
         gc.setFill(Color.BLUE);
         gc.fillOval(X_RIGHT_EYEO + xOffset, Y_RIGHT_EYEO + yOffset,EYE_WIDTH, EYE_HEIGHT);
         gc.fillOval(X_LEFT_EYEO + xOffset, Y_LEFT_EYEO + yOffset,EYE_WIDTH, EYE_HEIGHT);
         
         // Draw noses
         gc.setFill(Color.BLACK);
         gc.fillOval(X_NOSEO + xOffset, Y_NOSEO + yOffset,NOSE_DIAMETER, NOSE_DIAMETER);
         
         // Draw mouth
         gc.setStroke(Color.RED);
         gc.strokeArc(X_MOUTHO + xOffset, Y_MOUTHO + yOffset, MOUTH_WIDTH, MOUTH_HEIGHTO + i + 1, MOUTH_START_ANGLE,
        		 MOUTH_EXTENT_ANGLE,ArcType.OPEN);
         
         gc.setFont(Font.font("Times New Roman", 12));
         gc.fillText("Kiss!!.", X_FACEO + xOffset + FACE_DIAMETER, Y_FACEO + yOffset + 5);
         }
         
         xOffset = 50 * i;
         yOffset = 30 * i;
         
         // Draw kissing face
         gc.setFill(Color.WHITE);
         gc.setStroke(Color.BLACK);
         gc.strokeOval(X_FACEO + xOffset, Y_FACEO + yOffset, FACE_DIAMETER, FACE_DIAMETER);
         
         // Draw eyes
         gc.setFill(Color.BLUE);
         gc.fillOval(X_RIGHT_EYEO + xOffset, Y_RIGHT_EYEO+yOffset, EYE_WIDTH, EYE_HEIGHT);
         gc.fillOval(X_LEFT_EYEO + xOffset, Y_LEFT_EYEO+yOffset, EYE_WIDTH, EYE_HEIGHT);  
         
         // Draw nose
         gc.setFill(Color.BLACK);
         gc.fillOval(X_NOSEO + xOffset,  Y_NOSEO + yOffset, NOSE_DIAMETER, NOSE_DIAMETER);
         
         // Draw mouth in shape of a kiss
         gc.setFill(Color.RED);
         gc.fillOval(X_MOUTHO + xOffset + 10, Y_MOUTHO + yOffset, MOUTH_WIDTH - 20,  MOUTH_WIDTH -20 );
         
         gc.setFill(Color.BLACK);
         gc.setFont(Font.font("Times New Roman", 12));
         gc.fillText("Kiss, Kiss.", X_FACEO + xOffset + FACE_DIAMETER, Y_FACEO + yOffset);
         
         i++;
         xOffset = 50 * i;
         yOffset = 30 * i;
         
         gc.setFill(Color.GRAY);
         gc.fillOval(X_FACEO + xOffset, Y_FACEO + yOffset, FACE_DIAMETER, FACE_DIAMETER);
         gc.setStroke(Color.BLACK);
         gc.strokeOval(X_FACEO + xOffset,  Y_FACEO + yOffset,  FACE_DIAMETER,  FACE_DIAMETER);
         
         // Draw eyes
         gc.setFill(Color.BLUE);
         gc.fillOval(X_RIGHT_EYEO + xOffset, Y_RIGHT_EYEO+yOffset, EYE_WIDTH, EYE_HEIGHT);
         gc.fillOval(X_LEFT_EYEO + xOffset, Y_LEFT_EYEO+yOffset, EYE_WIDTH, EYE_HEIGHT);  
         
         // Draw nose
         gc.setFill(Color.BLACK);
         gc.fillOval(X_NOSEO + xOffset,  Y_NOSEO + yOffset, NOSE_DIAMETER, NOSE_DIAMETER);
         
         // Draw Tee Hee mouth
         gc.setStroke(Color.RED);
         gc.strokeArc(X_MOUTHO + xOffset , Y_MOUTHO + yOffset, MOUTH_WIDTH,  MOUTH_HEIGHTO + 3 *(i-6), MOUTH_START_ANGLE, 
        		  		MOUTH_EXTENT_ANGLE, ArcType.OPEN);
        
         
         gc.setFont(Font.font("Courier View", 16));
         gc.fillText("Tee Hee.", X_FACEO + xOffset + FACE_DIAMETER, Y_FACEO + yOffset);
         
         root.getChildren().add(canvas);
         primaryStage.setTitle("MulipleFaces in JavaFX");
         primaryStage.setScene(scene);
         primaryStage.show();
         
         
      }
 }