import java.util.Scanner;

public class CH04_MyDrawing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		System.out.println("Please input a number: ");
		int num = s.nextInt();
		int cnt = 0;
		
		for(int i = 1 ; i <= num * 2 ; i++ ) {
			if(i <= num) 
			{
				for(int j = 1 ; j <= i ; j++) {
					System.out.print("*");
				}
			}
			else if(i > num) 
			{
				for(int k = 2*num ; k >= i ; k--) {
					System.out.print("*");
				}
			}
			System.out.println();
		}
		s.close();
	}

}
