import java.util.Scanner;

public class CH04_MySummation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		int sum = 0;
		
		System.out.println("Please input a number: ");
		int num = s.nextInt();
		
		for(int i = 1 ; i <= num; i++) {
			sum += i;
		}
		
		System.out.println("The summation from 1 to " + num + " is");
		System.out.println(sum);

	}

}
