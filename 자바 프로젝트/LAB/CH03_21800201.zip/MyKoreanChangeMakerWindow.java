import javax.swing.JOptionPane;

public class MyKoreanChangeMakerWindow {
	

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		int number;
		
		number = Integer.parseInt(JOptionPane.showInputDialog("Enter a whole number from 1 to 10000"));
		
		int real_number = number;
		
		int five_num = number/500;
		number = number % 500;
		int four_num = number/100;
		number = number % 100;
		int three_num = number/10;
		number = number % 10;
		int two_num = number / 5;
		number = number % 5;
		int one_num = number / 1;
		number = number % 1;
		
		JOptionPane.showMessageDialog(null, real_number + " won in coins can be given as:\n" + five_num + " 500 won\n"
				+ four_num + " 100 won\n" + three_num + " 10 won\n" + two_num + " 5 won\n" + one_num + " 1 won\n",
				"�޽���", JOptionPane.INFORMATION_MESSAGE);

	}

}
