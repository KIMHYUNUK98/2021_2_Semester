import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;


public class CH10_Grader {

	public static void run(String fileName, String outfileName) {
		// TODO Auto-generated method stub
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File("C:\\Users\\vldrj\\eclipse-workspace\\CH10\\src\\" + fileName)));
			BufferedWriter wr = new BufferedWriter(new FileWriter(new File("C:\\Users\\vldrj\\eclipse-workspace\\CH10\\src\\" + outfileName)));
			
			String line = " ";
			double total = 0;
			double java_total = 0;
			double ds_total = 0;
			double oss_total = 0;
			double cal_total = 0;
			
			double average = 0;
			double java_average = 0;
			double ds_average = 0;
			double oss_average = 0;
			double cal_average = 0;
			double total_average = 0;
					
			while((line = br.readLine()) != null) {
				String arr[] = line.split(",");
				
				if(Character.isDigit(arr[2].charAt(0))) {
					//System.out.println(Double.parseDouble(arr[2]));
					double java = Double.parseDouble(arr[2]);
					double ds = Double.parseDouble(arr[3]);
					double oss = Double.parseDouble(arr[4]);
					double cal = Double.parseDouble(arr[5]);
					
					total = java + ds + oss + cal;
					java_total += java;
					ds_total += ds;
					oss_total += oss;
					cal_total += cal;
					
					average = total / 4.0;	
					total_average += average;
					
					wr.write(line+ "," + average);
				} else {
					wr.write(line + ", Average");
				}
				wr.newLine();
			}
			
			java_average = java_total / 8.0;
			ds_average = ds_total / 8.0;
			oss_average = oss_total / 8.0;
			cal_average = cal_total / 8.0;
			total_average = total_average / 8.0;
			
			wr.write("Average,000000," + java_average + "," + ds_average + "," + oss_average + "," + cal_average + "," + total_average);
			br.close();
			wr.close();
		}
		catch(FileNotFoundException e) {
			System.out.println("Can't not found");
		}
		catch(IOException e) {
			System.out.println("Problem with input file");
		}
	}

	

}
