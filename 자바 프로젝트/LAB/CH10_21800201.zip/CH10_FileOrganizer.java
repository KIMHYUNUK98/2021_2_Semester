import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.FlowPane;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class CH10_FileOrganizer extends Application {
	
	private TextField firstLineField;
	private TextField fileNameField;

	public static void main(String[] args) 
	{
		launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		final int WIDTH = 400;
		final int HEIGHT = 300;
		final int NUMBER_OF_PIXELS = 300;
			
		FlowPane root = new FlowPane();
			
		Button showButton = new Button("Multiply");
		root.getChildren().add(showButton);
		showButton.setOnAction(new EventHandler<ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event)
			{
				showFirstLine();
			}
		}
		);

		Button resetButton = new Button("Reset");
		root.getChildren().add(resetButton);
		resetButton.setOnAction(new EventHandler<ActionEvent>()
		{
			@Override
			public void handle(ActionEvent event)
			{
				resetFields();
			}
		}
		);
		
		fileNameField = new TextField("Enter output file name here.");
		
		fileNameField.setPrefWidth(NUMBER_OF_PIXELS);
		root.getChildren().add(fileNameField);
		
		firstLineField = new TextField("Enter Integer Number");
		firstLineField.setPrefWidth(NUMBER_OF_PIXELS);
		root.getChildren().add(firstLineField);
		
		Scene scene = new Scene(root, WIDTH, HEIGHT);
		
	primaryStage.setTitle("File Organizer");
	primaryStage.setScene(scene);
	primaryStage.show();
	}
	private void showFirstLine(){
		Scanner fileInput = null;
		String fileName = fileNameField.getText( );
		File fileObject = new File("C:\\Users\\vldrj\\eclipse-workspace\\CH10\\src\\" + fileName);
		
		if (!fileObject.exists( ))
			firstLineField.setText("No such file");
		else if (!fileObject.canRead( ))
			firstLineField.setText("That file is not readable.");
		else{
			try{
				fileInput = new Scanner(fileObject);
				timesTwo(fileName, Integer.parseInt(firstLineField.getText()));	
			}
			catch(FileNotFoundException e){
				firstLineField.setText("Error opening the file " + fileName);
			} 
			catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String firstLine = fileInput.nextLine( );
			firstLineField.setText("completed!");
			fileNameField.setText("output file : " + fileName);
			fileInput.close( );
		}
	}
	
	private void resetFields(){
		fileNameField.setText("Enter output file name here.");
		firstLineField.setText("Enter Integer Number");
	}
	
	public void timesTwo(String fileName, int mult) throws IOException{
			
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File("C:\\Users\\vldrj\\eclipse-workspace\\CH10\\src\\input2.txt")));
			BufferedWriter wr = new BufferedWriter(new FileWriter(new File("C:\\Users\\vldrj\\eclipse-workspace\\CH10\\src\\" + fileName)));
			
			String line = " ";
			while((line = br.readLine()) != null) {
				//System.out.println(line);
				int next = Integer.parseInt(line);
				wr.write(Integer.toString(mult * next));
				wr.newLine();
			}
			
			br.close();
			wr.close();
		}
		catch(EOFException e){
		//Do nothing. This just ends the loop.
		}
		catch(IOException e){
			firstLineField.setText("No such file");
			System.out.println(e.getMessage( ));
			System.exit(0);
		}
	}
	
}


