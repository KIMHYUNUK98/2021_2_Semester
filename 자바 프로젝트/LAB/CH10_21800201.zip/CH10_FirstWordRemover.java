import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.BufferedWriter;

public class CH10_FirstWordRemover {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub		
		Scanner s = new Scanner(System.in);
		System.out.println("What is the file to read from?");
		String infile = s.next();
		System.out.println("What is the file to write to(after removing the first word from each line)");
		String outfile = s.next();
		
		try {	
			BufferedReader br = new BufferedReader(new FileReader(new File("C:\\Users\\vldrj\\eclipse-workspace\\CH10\\src\\" + infile)));
			BufferedWriter wr = new BufferedWriter(new FileWriter(new File("C:\\Users\\vldrj\\eclipse-workspace\\CH10\\src\\" + outfile)));
			
			String line = " ";
			while((line = br.readLine()) != null) {
				String arr[] = line.split(" ");
				for(int i = 1 ; i < arr.length ; i++) {
					wr.write(arr[i] + " ");
				}
				wr.newLine();
			}
			
			br.close();
			wr.close();
			System.out.println("File processing completed");
		}
		catch(FileNotFoundException e) {
			System.out.println("Error opening file ");
			System.exit(0);
		}
	}

}
