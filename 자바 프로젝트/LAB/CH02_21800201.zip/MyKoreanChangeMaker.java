import java.util.Scanner;

public class MyKoreanChangeMaker {
	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter a whole number from 1 to 10000.");
		int number = s.nextInt();
		int real_number = number;
		
		int five_num = number/500;
		number = number % 500;
		int four_num = number/100;
		number = number % 100;
		int three_num = number/10;
		number = number % 10;
		int two_num = number / 5;
		number = number % 5;
		int one_num = number / 1;
		number = number % 1;
		
		System.out.println(real_number + " won in coins can be given as: ");
		System.out.println(five_num + " 500 won");
		System.out.println(four_num + " 100 won");
		System.out.println(three_num + " 10 won");
		System.out.println(two_num + " 5 won");
		System.out.println(one_num + " 1 won");
	}
}
