import java.util.Scanner;

public class MyFtoC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter a temperature in degrees Fagrenheit: ");
		
		int fahr = s.nextInt();
		double temper = 5 * ((double)fahr - 32) / 9; 
		
		System.out.println(fahr + " degrees Fahrenheit = " + temper + " degrees Celsius.");
	}

}
