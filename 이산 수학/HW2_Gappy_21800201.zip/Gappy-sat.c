#include <stdio.h>
#include <string.h>

int main()
{
        FILE *fp = fopen("Gappy-formula", "w");

        int i, j;
        char white = 'W';
        char black = 'B';

        for(i = 1 ; i <= 9 ; i++) {
                for(j = 1 ; j <= 9 ; j++) {
                        fprintf(fp, "(declare-const p%d%d%c Bool)\n", i , j , white);
                        fprintf(fp, "(declare-const p%d%d%c Bool)\n", i , j , black);
                }
        }



        int gap[5][12];
        int number = 0;
        //Setting Gappy
        for(i = 1 ; i <= 2 ; i++) {
                for( j = 1 ; j <= 9 ; j++) {
                        scanf("%d", &number);
                        gap[i][j] = number;
                }
        }
        //Setiing All cell with XOR (WHITE BLACK)
        fprintf(fp, "; setting with XOR GATE\n");
        fprintf(fp, "(assert (and ");
        for(i = 1 ; i <= 9 ; i++) {
                for(j = 1 ; j <= 9 ;j++) {
                        fprintf(fp, "(xor p%d%d%c p%d%d%c)", i,j,black, i,j, white);
                }
        }
        fprintf(fp, "))\n");


        // condition 1
        fprintf(fp, "; condition1\n");
        fprintf(fp, "(assert (and ");
        for(i = 1 ; i <= 9 ; i++){
                fprintf(fp, "(and ");
                for(j = 1 ; j <= 8 ; j++) {
                        fprintf(fp, "(not (and p%d%d%c p%d%d%c))", i,j,black, i,j+1,black);
                }
                fprintf(fp, ")");
        }
        fprintf(fp,"))\n");

        // condition 1_2
        fprintf(fp, "; condition1_2\n");
        fprintf(fp, "(assert (and ");
        for(j = 1 ; j <= 9 ; j++) {
                fprintf(fp, "(and ");
                for(i = 1 ; i <= 8 ; i++) {
                        fprintf(fp, "(not (and p%d%d%c p%d%d%c))", i,j,black, i+1,j,black);
                }
                fprintf(fp, ")");
        }
        fprintf(fp, "))\n");

        // condition 1_3
        fprintf(fp, "; condition1_3\n");
        fprintf(fp, "(assert (and ");
        for(i = 1 ; i <= 8 ; i++) {
                fprintf(fp, "(and ");
                for(j = 1 ; j <= 8 ; j++) {
                        fprintf(fp, "(not (and p%d%d%c p%d%d%c))" ,i,j,black, i+1,j+1,black);
                }
                fprintf(fp, ")");
        }
        fprintf(fp, "))\n");

        // condition 1_4
        fprintf(fp, "; condition1_4\n");
        fprintf(fp, "(assert (and ");
        for(i = 1 ; i <= 8 ; i++) {
                fprintf(fp, "(and ");
                for(j = 2 ; j <= 9 ; j++) {
                        fprintf(fp, "(not (and p%d%d%c p%d%d%c))", i,j,black, i+1,j-1,black);
                }
                fprintf(fp, ")");
        }
        fprintf(fp, "))\n");

        // condition 2_1
        // row
        fprintf(fp, "; condition2_1\n");
        fprintf(fp, "(assert (and ");
        for(i = 1 ; i <= 9 ; i++) {
                fprintf(fp, "(and ");
                for(j = 1 ; j <= 7 ; j++) {
                        for(int m = j+1 ; m <= 8 ; m++) {
                                for(int k = m +1 ; k <= 9 ; k++) {
                                        fprintf(fp, "(not (and p%d%d%c p%d%d%c p%d%d%c))", i,j,black, i,m,black, i,k,black);
                                }
                        }
                }
                fprintf(fp, ")");
        }
        fprintf(fp, "))\n");

        // condition 2_2
        // row
        fprintf(fp, "; condition2_2\n");
        fprintf(fp, "(assert (and ");
        for(i = 1 ; i <= 9 ; i++) {
                fprintf(fp, "(or ");
                for(j = 1 ; j <= 8 ; j++) {
                        for(int m = j+1 ; m <= 9 ; m++) {
                                fprintf(fp, "(and p%d%d%c p%d%d%c)", i,j,black, i,m,black);
                        }
                }
                fprintf(fp, ")");
        }
        fprintf(fp, "))\n");

        // condition 2_3
        // column
        fprintf(fp, "; condition2_3\n");
        fprintf(fp, "(assert (and ");
        for(j = 1 ; j <= 9 ; j++) {
                fprintf(fp, "(and ");
                for(i = 1 ; i <= 7 ; i++) {
                        for(int m = i+1 ; m <= 8 ; m++) {
                                for(int k = m +1 ; k <= 9 ; k++) {
                                        fprintf(fp, "(not (and p%d%d%c p%d%d%c p%d%d%c))", i,j,black, m,j,black, k,j,black);
                                }
                        }
                }
                fprintf(fp, ")");
        }
        fprintf(fp, "))\n");

        // condition 2_4
        // column
        fprintf(fp, "; condition2_4\n");
        fprintf(fp, "(assert (and ");
        for(j = 1 ; j <= 9 ; j++) {
                fprintf(fp, "(or ");
                for(i = 1 ; i <= 8 ; i++) {
                        for(int m = i+1 ; m <= 9 ; m++) {
                                fprintf(fp, "(and p%d%d%c p%d%d%c)", i,j,black, m,j,black);
                        }
                }
                fprintf(fp, ")");
        }
        fprintf(fp, "))\n");

        // condition 3_1
        fprintf(fp, "; condition3_1\n");
        fprintf(fp, "(assert (and ");
        for(i = 1 ; i <= 9 ; i++) {
                fprintf(fp, "(or ");
                for(j = 1 ; j + gap[1][i]+1 <= 9 ; j++) {
                        fprintf(fp, "(and p%d%d%c p%d%d%c)", i,j,black, i, j + gap[1][i]+1 ,black);
                }
                fprintf(fp, ")");
        }
        fprintf(fp, "))\n");

        // condition 3_2
        fprintf(fp, "; condition3_2\n");
        fprintf(fp, "(assert (and ");
        for(j = 1 ; j <= 9 ; j++) {
                fprintf(fp, "(or ");
                for(i = 1 ; i + gap[2][j]+1 <= 9 ; i++) {
                        fprintf(fp, "(and p%d%d%c p%d%d%c)", i,j,black, i+gap[2][j]+1,j,black);
                }
                fprintf(fp, ")");
        }
        fprintf(fp, "))\n");

        fprintf(fp, "(check-sat)\n(get-model)\n");

        fclose(fp);

        FILE *fin = popen("z3 Gappy-formula", "r");
        char buf[128];
        char buf1[128];
        char buf2[128];
        char buf3[128];
        char buf4[128];
        char buf5[128];

        char answer[11][11];
        fscanf(fin, "%s %s", buf1, buf);

        if(strcmp(buf1,"unsat") == 0) {
                printf("No Solution!\n");
                return 0;
        }

        while(!feof(fin)) {
                fscanf(fin ,"%s", buf1) ;// printf("%s ", buf1);
                fscanf(fin ,"%s", buf2) ;//printf("%s ", buf2);
                fscanf(fin ,"%s", buf3) ;// printf("%s ", buf3);
                fscanf(fin ,"%s", buf4) ;// printf("%s ", buf4);
                fscanf(fin ,"%s", buf5) ;//printf("%s \n", buf5);

                if(buf2[strlen(buf2)-1] == 'W' && strcmp(buf5, "true)") == 0) {
                        answer[buf2[1] - '0'][buf2[2] - '0'] = 'W';
                }
                else if(buf2[strlen(buf2)-1] == 'B' && strcmp(buf5, "true)") == 0) {
                        answer[buf2[1] - '0'][buf2[2] - '0'] = 'B';
                }

        }

        // answer
        for(i = 1 ; i <= 9 ; i++) {
                for(j = 1 ; j <= 9 ; j++) {
                        printf("%c ", answer[i][j]);
                }
        printf("\n");
        }

        pclose(fin);
}