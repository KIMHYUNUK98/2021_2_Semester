#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(){
	FILE * fp = fopen("formula", "w");
	
	int i,j,n,k;

	for (i = 1 ; i <= 9 ; i++)
		for (j = 1 ; j <= 9 ; j++)
			for (n = 1 ; n < 10 ; n++)
				fprintf(fp,"(declare-const p%d%d%d Bool)\n", i, j, n) ;

	char c;

	fprintf(fp, "(assert (and ");
	for (i=1; i<10; i++){
		for (j=1; j<10; j++){
			scanf("%c",&c);
			while (isspace(c)){
				scanf("%c", &c);
			}
			if (isdigit(c)){
				fprintf(fp, "p%d%d%d ", i,j,c-'0');
			}
		}
	}
	printf("\n");

	fprintf(fp, "))\n");

	fprintf(fp,"; S1\n") ;

	fprintf(fp, "(assert (and ");
	for (i=1; i<10; i++){
		fprintf(fp, "(and ");
		for (j=1; j<10; j++){
			fprintf(fp, "(and ");
			for (n=1; n<9; n++){
				fprintf(fp, "(and ");
				for (k=n+1; k<10; k++){
					fprintf(fp, "(not (and p%d%d%d p%d%d%d)) ", i, j, n, i, j, k);
				}
				fprintf(fp, ")");
			}
			fprintf(fp, ")");
		}
		fprintf(fp,")");
	}
	fprintf(fp, "))\n");


	fprintf(fp, "; S2\n");
	fprintf(fp, "(assert (and ");
	for (i=1; i<10; i++){
		fprintf(fp, "(and ");
		for (j=1; j<10; j++){
			fprintf(fp, "(or ");
			for (n=1; n<10; n++){
				fprintf(fp, "p%d%d%d ", i, j, n);
			}
			fprintf(fp,")");
		}
		fprintf(fp, ")");
	}
	fprintf(fp, "))\n");

	fprintf(fp, "; S3\n");
	fprintf(fp, "(assert (and ");
        for (i=1; i<10; i++){
                fprintf(fp, "(and ");
                for (n=1; n<10; n++){
                        fprintf(fp, "(or ");
                        for (j=1; j<10; j++){
                                fprintf(fp, "p%d%d%d ", i, j, n);
                        }
                        fprintf(fp, ")");
                }
                fprintf(fp,")");
        }
        fprintf(fp, "))\n");

	fprintf(fp, "; S4\n");
        fprintf(fp, "(assert (and ");
        for (j=1; j<10; j++){
                fprintf(fp, "(and ");
                for (n=1; n<10; n++){
                        fprintf(fp, "(or ");
                        for (i=1; i<10; i++){
                                fprintf(fp, "p%d%d%d ", i, j, n);
                        }
                        fprintf(fp, ")");
                }
                fprintf(fp,")");
        }
        fprintf(fp, "))\n");

	fprintf(fp, "; S5\n");
        fprintf(fp, "(assert (and ");
	for (int s=0; s<3; s++){
                fprintf(fp, "(and ");
                for (int r=0; r<3; r++){
                        fprintf(fp, "(and ");
                        for (n=1; n<10; n++){
                                fprintf(fp, "(or ");
                                for (i=1; i<4; i++){
					fprintf(fp, "(or ");
					for (j=1; j<4; j++){
                                        	fprintf(fp, "p%d%d%d ",3*s+i,3*r+j,n);
					}
					fprintf(fp, ")");
                                }
                                fprintf(fp, ")");
                        }
                        fprintf(fp, ")");
                }
                fprintf(fp,")");
        }
        fprintf(fp, "))\n");


	fprintf(fp, "; S8\n");
        fprintf(fp, "(assert (and ");
        for (i=1; i<9; i++){
                fprintf(fp, "(and ");
                for (j=1; j<9; j++){
                        fprintf(fp, "(and ");
                        for (n=1; n<10; n++){
                                fprintf(fp, "(not (and p%d%d%d p%d%d%d)) ", i,j,n,i+1,j+1,n);
                        }
                        fprintf(fp, ")");
                }
                fprintf(fp, ")");
        }
        fprintf(fp, "))\n");

	fprintf(fp, "; S9\n");
        fprintf(fp, "(assert (and ");
        for (i=1; i<9; i++){
                fprintf(fp, "(and ");
                for (j=2; j<10; j++){
                        fprintf(fp, "(and ");
                        for (n=1; n<10; n++){
                                fprintf(fp, "(not (and p%d%d%d p%d%d%d)) ", i,j,n,i+1,j-1,n);
                        }
                        fprintf(fp, ")");
                }
                fprintf(fp, ")");
        }
        fprintf(fp, "))\n");

	fprintf(fp,"(check-sat)\n(get-model)\n") ;

	fclose(fp) ;

	FILE * fin = popen("z3 formula", "r") ;
	char buf1[128] ;
	char buf2[128] ;
	char buf3[128] ;
	char buf4[128] ;
	char buf5[128] ;
	
	int list[9][9]={0};
	fscanf(fin, "%s %s", buf2, buf4) ;
	if (strcmp(buf2,"unsat")==0){
		printf("No solution");
		return 0;
	}
	while (!feof(fin)) {
		fscanf(fin, "%s %s %s %s %s", buf1, buf2, buf3, buf4, buf5) ; 
		if (strcmp(buf5,"true)")==0){
			list[buf2[1]-'0'-1][buf2[2]-'0'-1]=buf2[3]-'0';
			
		}
	}
	for (int i=0; i<9; i++){
		for (int j=0; j<9; j++){
			printf("%d ", list[i][j]);
		}
		printf("\n");
	}
	pclose(fin) ;


}
