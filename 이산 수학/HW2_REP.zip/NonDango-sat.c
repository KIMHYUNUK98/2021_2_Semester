#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main () {
 FILE *fp = fopen("Non-formula", "w");

 int i , j , r;
 char non = 'X';
 char white = 'W';
 char black = 'B';

 for(i = 1 ; i <= 10 ; i++) {
        for(j = 1 ; j <= 10 ; j++) {
                fprintf(fp, "(declare-const p%d%d%c Bool)\n", i,j,non);
                fprintf(fp, "(declare-const p%d%d%c Bool)\n", i,j,white);
                fprintf(fp, "(declare-const p%d%d%c Bool)\n", i,j,black);
                for(r = 1 ; r <= 50 ; r++) {
                        fprintf(fp, "(declare-const p%d%d%d Bool)\n", i,j,r);
                }
        }
 }
 fprintf(fp, "\n");

 char read[12];

 int count[50] = { 0 };
 int region[51][17];
 int max = 0;

 fprintf(fp, "; setting Nondango\n");
 fprintf(fp, "(assert (and ");

 for(int m = 1 ; m <= 10 ; m++) {
        for(int k = 1 ; k <= 10 ; k++) {
                scanf("%s", read);
                int len = strlen(read);
                if(read[len-1] != 'W') {
                        fprintf(fp, "(and p%d%d%c p%d%d%d )", m,k,non, m,k,atoi(read));
                } else {
                        fprintf(fp, "(and (xor p%d%d%c p%d%d%c) p%d%d%d)", m,k,white, m,k,black, m,k,atoi(read));
                }
                region[atoi(read)][count[atoi(read)]++] = m;
                region[atoi(read)][count[atoi(read)]++] = k;
                if(max < atoi(read)) max = atoi(read);
        }
 }
 fprintf(fp, "))\n\n");

 //DEBUGING
 int region_size = max;
 int sum = 0;
/*
 for(int i = 1 ; i <= region_size ; i++) {
        printf("region %d = ", i);
        for(int j = 0 ; j < count[i] ; j = j + 2) {
                printf("[%d %d] ", region[i][j], region[i][j+1]);
        }
 printf("\n");
 }
*/
 // condition 1
 fprintf(fp, "; condition 1\n");
 fprintf(fp, "(assert (and ");
 // Rotate Every region size
 for(r = 1 ; r <= region_size ; r++) {
        // Rotate each Region size
        for(int m = 0 ; m <= count[r] - 4 ; m = m + 2) {
                for(int n = m + 2 ; n < count[r] ; n = n + 2) {
                        fprintf(fp, "(not (and p%d%d%c p%d%d%c))", region[r][m], region[r][m+1], black, region[r][n], region[r][n+1],black);
                }
        }
 }
 fprintf(fp, "))\n");

 // condition 1_2
 fprintf(fp, "; condition 1_1\n");
 fprintf(fp, "(assert (and ");
 for(r = 1 ; r <= region_size ; r++) {
        fprintf(fp, "(not (and ");
        for(int k = 0 ; k < count[r] ; k = k + 2) {
                fprintf(fp, "(or p%d%d%c p%d%d%c)", region[r][k], region[r][k+1], non, region[r][k], region[r][k+1], white);
        }
        fprintf(fp, "))");
 }
 fprintf(fp, "))\n");


 // condition 2_1
 // column_Black
 fprintf(fp, "; condition 2_1 \n");
 fprintf(fp, "(assert (and ");
 for(i = 1 ; i <= 10 ; i++) {
        fprintf(fp, "(and ");
        for(j = 1 ; j <= 8 ; j++) {
                fprintf(fp, "(not (and p%d%d%c p%d%d%c p%d%d%c))", i,j,black, i,j+1,black, i,j+2,black);
        }
        fprintf(fp, ")");
 }
 fprintf(fp, "))\n");


 // condition 2_2
 // row_Black
 fprintf(fp, "; condition 2_2 \n");
 fprintf(fp, "(assert (and ");
 for(j = 1 ; j <= 10 ; j++) {
        fprintf(fp, "(and ");
        for(i = 1 ; i <= 8 ; i++) {
                fprintf(fp, "(not (and p%d%d%c p%d%d%c p%d%d%c))", i,j,black, i+1,j,black, i+2,j,black);
        }
        fprintf(fp, ")");
 }
 fprintf(fp, "))\n");

 // condition 2_3
 // column_White
 fprintf(fp, "; condition 2_3 \n");
 fprintf(fp, "(assert (and ");
 for(i = 1 ; i <= 10 ; i++) {
        fprintf(fp, "(and ");
        for(j = 1 ; j <= 8 ; j++) {
                fprintf(fp, "(not (and p%d%d%c p%d%d%c p%d%d%c))", i,j,white, i,j+1,white, i,j+2,white);
        }
        fprintf(fp, ")");
 }
 fprintf(fp, "))\n");


 // condition 2_4
 // row_White
 fprintf(fp, "; condition 2_4 \n");
 fprintf(fp, "(assert (and ");
 for(j = 1 ; j <= 10 ; j++) {
        fprintf(fp, "(and ");
        for(i = 1 ; i <= 8 ; i++) {
                fprintf(fp, "(not (and p%d%d%c p%d%d%c p%d%d%c))", i,j,white, i+1,j,white, i+2,j,white);
        }
        fprintf(fp, ")");
 }
 fprintf(fp, "))\n");


 // condition 2_5
 // diagnol_right_black
 fprintf(fp, "; condition 2_5 \n");
 fprintf(fp, "(assert (and ");
 for(i = 1 ; i <= 8 ; i++) {
        fprintf(fp, "(and ");
        for(j = 1 ; j <= 8 ; j++) {
                fprintf(fp, "(not (and p%d%d%c p%d%d%c p%d%d%c))", i,j,black, i+1,j+1,black, i+2,j+2,black);
        }
        fprintf(fp, ")");
 }
 fprintf(fp, "))\n");

 // condition 2_6
 //diagnol_left_black
 fprintf(fp, "; condition 2_6 \n");
 fprintf(fp, "(assert (and ");
 for(i = 1 ; i <= 8 ; i++) {
        fprintf(fp, "(and ");
        for(j = 3 ; j <= 10 ; j++) {
                fprintf(fp, "(not (and p%d%d%c p%d%d%c p%d%d%c ))", i,j,black, i+1,j-1,black, i+2,j-2,black);
        }
        fprintf(fp, ")");
 }
 fprintf(fp, "))\n");


 // condition 2_7
 // diagnol_right_white
 fprintf(fp, "; condition 2_7 \n");
 fprintf(fp, "(assert (and ");
 for(i = 1 ; i <= 8 ; i++) {
        fprintf(fp, "(and ");
        for(j = 1 ; j <= 8 ; j++) {
                fprintf(fp, "(not (and p%d%d%c p%d%d%c p%d%d%c))", i,j,white, i+1,j+1,white, i+2,j+2,white);
        }
        fprintf(fp, ")");
 }
 fprintf(fp, "))\n");

 // condition 2_8
 //diagnol_left_white
 fprintf(fp, "; condition 2_8 \n");
 fprintf(fp, "(assert (and ");
 for(i = 1 ; i <= 8 ; i++) {
        fprintf(fp, "(and ");
        for(j = 3 ; j <= 10 ; j++) {
                fprintf(fp, "(not (and p%d%d%c p%d%d%c p%d%d%c ))", i,j,white, i+1,j-1,white, i+2,j-2,white);
        }
        fprintf(fp, ")");
 }
 fprintf(fp, "))\n");


 fprintf(fp, "(check-sat)\n(get-model)\n");

 fclose(fp);

 FILE * fin = popen("z3 Non-formula", "r");
 char buf9[128];
 char buf1[128];
 char buf2[128];
 char buf3[128];
 char buf4[128];
 char buf5[128];
 fscanf(fin, "%s %s", buf9, buf2);
 if(strcmp(buf9, "unsat") == 0) {
        printf("No solution\n");
        return 0;
 }



 char array[12][12];
 while(!feof(fin)) {
        fscanf(fin, "%s", buf1) ; //printf("%s ", buf1);
        fscanf(fin, "%s", buf2) ; //printf("%s ", buf2);
        fscanf(fin, "%s", buf3) ; //printf("%s ", buf3);
        fscanf(fin, "%s", buf4) ; //printf("%s ", buf4);
        fscanf(fin, "%s", buf5) ; //printf("%s\n", buf5);
        if((buf2[strlen(buf2)-1] == 'X') &&  (strcmp(buf5, "true)") == 0)) {

                if(buf2[1] >= '1' && buf2[1] <= '9' && buf2[2] != '0' && buf2[3] != '0') {
                        array[buf2[1] - '0'][buf2[2] - '0'] = 'X';
                }
                else if(buf2[1] == '1' && buf2[2] == '0' && buf2[4] != '0') {
                        array[10][buf2[3] - '0'] = 'X';
                }

                else if(buf2[1] >= '1' && buf2[1] <= '9' && buf2[2] != '0' && buf2[3] == '0') {
                        array[buf2[1] - '0'][10] = 'X';
                }

                else if(buf2[1] == '1' && buf2[2] == '0' && buf2[3] == '1' && buf2[4] == '0') {
                        array[10][10] = 'X';
                }
        }

        if((buf2[strlen(buf2)-1] == 'W') &&  (strcmp(buf5, "true)") == 0)) {

                if((buf2[1] >= '1') && (buf2[1] <= '9') && buf2[2] != '0' && buf2[3] != '0') {
                        array[buf2[1] - '0'][buf2[2] - '0'] = 'W';
                }
                else if( buf2[1] == '1' && buf2[2] == '0' && buf2[4] != '0') {
                        array[10][buf2[3] - '0'] = 'W';
                }

                else if((buf2[1] >= '1') && (buf2[1] <= '9') && buf2[2] != '0' && buf2[3] == '0') {
                        array[buf2[1] - '0'][10] = 'W';
                }

                else if(buf2[1] == '1' && buf2[2] == '0' && buf2[3] == '1' && buf2[4] == '0') {
                        array[10][10] = 'W';
                }
        }

        if((buf2[strlen(buf2)-1] == 'B') &&  (strcmp(buf5, "true)") == 0)) {

                if((buf2[1] >= '1') && (buf2[1] <= '9') && buf2[2] != '0' && buf2[3] != '0') {
                        array[buf2[1] - '0'][buf2[2] -'0'] = 'B';
                }
                else if( buf2[1] == '1' && buf2[2] == '0' && buf2[4] != '0') {
                        array[10][buf2[3] - '0'] = 'B';
                }

                else if((buf2[1] >= '1') && (buf2[1] <= '9') && buf2[2] != '0' && buf2[3] == '0') {
                        array[buf2[1] -'0'][10] = 'B';
                }

                else if(buf2[1] == '1' && buf2[2] == '0' && buf2[3] == '1' && buf2[4] == '0') {
                        array[10][10] = 'B';
                }
        }
 }


 // Answer
 for(int i = 1 ; i <= 10 ; i++) {
        for(int j = 1 ; j <= 10; j++) {
                printf(" %c ", array[i][j]);
        }
        printf("\n");
 }

 pclose(fin);

}